
let tips = [];
let fuse = null;
let activeTopics = new Set();
let searchQuery = "";
let sortMode = "date_desc";

const els = {
  topicsList: () => document.getElementById("topicsList"),
  searchInput: () => document.getElementById("searchInput"),
  searchMeta: () => document.getElementById("searchMeta"),
  sortSelect: () => document.getElementById("sortSelect"),
  clearTopics: () => document.getElementById("clearTopics"),
  cards: () => document.getElementById("cards"),
  stats: () => document.getElementById("stats"),
  empty: () => document.getElementById("empty"),
  themeToggle: () => document.getElementById("themeToggle"),
};

function pickTheme() {
  const saved = localStorage.getItem("theme");
  if (saved === "light") document.documentElement.classList.add("light");
}
function toggleTheme() {
  document.documentElement.classList.toggle("light");
  const isLight = document.documentElement.classList.contains("light");
  localStorage.setItem("theme", isLight ? "light" : "dark");
}

function formatDate(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    if (isNaN(d)) return "";
    return d.toLocaleString("ru-RU", { year:"numeric", month:"short", day:"numeric" });
  } catch { return ""; }
}

function el(tag, attrs={}, ...children) {
  const node = document.createElement(tag);
  for (const [k,v] of Object.entries(attrs)) {
    if (k==="class") node.className=v;
    else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k,v);
  }
  for (const ch of children) node.append(ch);
  return node;
}

function renderTopics() {
  const counter = new Map();
  tips.forEach(t => t.topics.forEach(tp => counter.set(tp, (counter.get(tp)||0)+1)));
  const sorted = [...counter.entries()].sort((a,b)=>b[1]-a[1]);

  const container = els.topicsList();
  container.innerHTML = "";
  sorted.forEach(([tp,count])=>{
    const chip = el("div", {class:`topic-chip ${activeTopics.has(tp)?"active":""}`},
      el("span",{class:"name"}, tp),
      el("span",{class:"count"}, count)
    );
    chip.addEventListener("click", ()=>{
      if (activeTopics.has(tp)) activeTopics.delete(tp); else activeTopics.add(tp);
      renderTopics();
      render();
    });
    container.append(chip);
  });
}

function applyFilters() {
  let filtered = tips;

  // topics filter (AND logic)
  if (activeTopics.size>0) {
    filtered = filtered.filter(t => [...activeTopics].every(tp => t.topics.includes(tp)));
  }

  // search
  if (searchQuery.trim()) {
    if (!fuse) {
      const Fuse = window.Fuse;
      if (Fuse) {
        fuse = new Fuse(tips, { keys:["text","author","topics"], threshold:0.35, ignoreLocation:true, minMatchCharLength:2 });
      }
    }
    if (fuse) filtered = fuse.search(searchQuery).map(r=>r.item);
    else filtered = filtered.filter(t => (t.text+t.author+t.topics.join(" ")).toLowerCase().includes(searchQuery.toLowerCase()));
  }

  // sort
  const sorters = {
    date_desc: (a,b)=> (b._ts||0)-(a._ts||0),
    date_asc:  (a,b)=> (a._ts||0)-(b._ts||0),
    len_desc:  (a,b)=> b.text.length-a.text.length,
    len_asc:   (a,b)=> a.text.length-b.text.length,
    author_asc:(a,b)=> (a.author||"").localeCompare(b.author||"", "ru"),
  };
  filtered = filtered.slice().sort(sorters[sortMode] || sorters.date_desc);

  return filtered;
}

function render() {
  const filtered = applyFilters();
  const cards = els.cards();
  cards.innerHTML = "";

  els.stats().textContent = `Показано: ${filtered.length} из ${tips.length}`;

  els.empty().classList.toggle("hidden", filtered.length!==0);

  filtered.forEach(t=>{
    const textNode = el("div",{class:"text"}, t.text);

    const meta = el("div",{class:"meta"},
      el("span",{}, t.author || "—"),
      el("span",{}, formatDate(t.date))
    );

    const tags = el("div",{class:"tags"});
    t.topics.forEach(tp=>{
      const tag = el("div",{class:"tag"}, tp);
      tag.addEventListener("click", ()=>{
        if (activeTopics.has(tp)) activeTopics.delete(tp); else activeTopics.add(tp);
        renderTopics();
        render();
        window.scrollTo({top:0, behavior:"smooth"});
      });
      tags.append(tag);
    });

    const card = el("article",{class:"card"}, textNode, tags, meta);
    cards.append(card);
  });

  const metaEl = els.searchMeta();
  metaEl.textContent = searchQuery ? `Поиск: "${searchQuery}"` : "";
}

async function init() {
  pickTheme();
  els.themeToggle().addEventListener("click", toggleTheme);

  const res = await fetch("./tips.json");
  tips = await res.json();
  tips.forEach(t=> t._ts = t.date ? Date.parse(t.date) : 0);

  els.searchInput().addEventListener("input", (e)=>{
    searchQuery = e.target.value;
    render();
  });
  els.sortSelect().addEventListener("change", (e)=>{
    sortMode = e.target.value;
    render();
  });
  els.clearTopics().addEventListener("click", ()=>{
    activeTopics.clear();
    renderTopics();
    render();
  });

  renderTopics();
  render();
}

document.addEventListener("DOMContentLoaded", init);
